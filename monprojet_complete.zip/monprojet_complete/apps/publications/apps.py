from django.apps import AppConfig

class PublicationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.publications'
    verbose_name = 'Publications'

    def ready(self):
        import apps.publications.signals
