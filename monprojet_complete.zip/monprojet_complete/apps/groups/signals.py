from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Groupe
from config.mongodb import groups_coll
from bson.objectid import ObjectId

@receiver(post_save, sender=Groupe)
def sync_group_to_mongo(sender, instance, created, **kwargs):
    """
    Synchronize Groupe instance with MongoDB on save.
    """
    group_collection = groups_coll()

    mongo_doc = {
        'mysql_id': instance.id,
        'name': instance.name,
        'description': instance.description or '',
        'visibility': instance.visibility,
        'creator_id': str(instance.creator.id),
        
        'members': [
            {
                'user_id': str(membership.user.id),
                'username': membership.user.username,
                'full_name': membership.user.get_full_name() or membership.user.username,
                'role': membership.role,
                'joined_at': membership.joined_at.isoformat()
            }
            for membership in instance.groupmembership_set.all()
        ],
        
        'stats': {
            'member_count': instance.member_count,
            'post_count': instance.post_count
        },
        
        'created_at': instance.created_at.isoformat(),
        'updated_at': instance.updated_at.isoformat()
    }

    if instance.mongo_id:
        group_collection.update_one(
            {'_id': ObjectId(instance.mongo_id)},
            {'$set': mongo_doc}
        )
    else:
        result = group_collection.insert_one(mongo_doc)
        Groupe.objects.filter(pk=instance.pk).update(mongo_id=str(result.inserted_id))

@receiver(post_delete, sender=Groupe)
def delete_group_from_mongo(sender, instance, **kwargs):
    """
    Delete Groupe instance from MongoDB on delete.
    """
    if instance.mongo_id:
        group_collection = groups_coll()
        group_collection.delete_one({'_id': ObjectId(instance.mongo_id)})
