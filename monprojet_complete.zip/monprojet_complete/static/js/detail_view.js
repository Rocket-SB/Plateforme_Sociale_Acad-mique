document.addEventListener('DOMContentLoaded', function () {
    const imageModal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const modalCaption = document.getElementById('modalCaption');
    
    if (!imageModal) return;

    function openImageModal(src, caption) {
        if(src) modalImage.src = src;
        if(caption) modalCaption.textContent = caption;
        imageModal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    function closeImageModal() {
        imageModal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }

    // Use event delegation to handle clicks on images
    document.addEventListener('click', function(e) {
        // If a gallery image is clicked
        if (e.target.matches('.gallery-item img')) {
            e.preventDefault();
            const src = e.target.src;
            const caption = e.target.alt;
            openImageModal(src, caption);
        }

        // If the modal background or close button is clicked
        if (e.target.matches('.image-modal') || e.target.matches('.image-modal-close')) {
            closeImageModal();
        }
    });

    // Close modal with escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && imageModal.classList.contains('show')) {
            closeImageModal();
        }
    });
});
