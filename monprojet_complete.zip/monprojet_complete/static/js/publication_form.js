document.addEventListener('DOMContentLoaded', function () {

    // --- GENERIC DROP ZONE HANDLER ---
    function setupDropZone(dropZoneId, inputId, previewFunction) {
        const dropZone = document.getElementById(dropZoneId);
        const input = document.getElementById(inputId);
        if (!dropZone || !input) return;

        dropZone.addEventListener('click', () => input.click());

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                input.files = e.dataTransfer.files;
                // Create a 'change' event to trigger the preview
                const event = new Event('change', { bubbles: true });
                input.dispatchEvent(event);
            }
        });

        if (previewFunction) {
            input.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    previewFunction(e.target.files);
                }
            });
        }
    }

    // --- COVER IMAGE ---
    const coverPreview = document.getElementById('coverPreview');
    const coverPreviewImg = document.getElementById('coverPreviewImg');
    const coverDropZone = document.getElementById('coverDropZone');
    const coverInput = document.getElementById('cover_image');

    function previewCoverImage(files) {
        const file = files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            coverPreviewImg.src = e.target.result;
            coverPreview.style.display = 'block';
            coverDropZone.style.display = 'none';
        };
        reader.readAsDataURL(file);
    }

    function removeCoverImage() {
        coverInput.value = '';
        coverPreview.style.display = 'none';
        coverDropZone.style.display = 'block';
    }
    
    setupDropZone('coverDropZone', 'cover_image', previewCoverImage);
    const removeCoverBtn = document.querySelector('[data-action="remove-cover"]');
    if(removeCoverBtn) removeCoverBtn.addEventListener('click', removeCoverImage);


    // --- ADDITIONAL IMAGES ---
    const imagesPreview = document.getElementById('imagesPreview');
    const imagesInput = document.getElementById('images');
    let selectedImages = [];

    function handleImageFiles(files) {
        selectedImages = [...selectedImages, ...Array.from(files).filter(f => f.type.startsWith('image/'))];
        updateImagesPreview();
    }

    function updateImagesPreview() {
        imagesPreview.style.display = selectedImages.length > 0 ? 'grid' : 'none';
        imagesPreview.innerHTML = '';
        selectedImages.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const div = document.createElement('div');
                div.className = 'preview-item';
                div.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <button type="button" class="remove-btn" data-index="${index}">✕</button>
                `;
                imagesPreview.appendChild(div);
            };
            reader.readAsDataURL(file);
        });
    }

    function removeImage(index) {
        selectedImages.splice(index, 1);
        updateImagesPreview();
        // Update the files in the input
        const dataTransfer = new DataTransfer();
        selectedImages.forEach(file => dataTransfer.items.add(file));
        imagesInput.files = dataTransfer.files;
    }

    setupDropZone('imagesDropZone', 'images', handleImageFiles);
    imagesPreview.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-btn')) {
            removeImage(parseInt(e.target.dataset.index, 10));
        }
    });

    // --- DOCUMENT ---
    const documentPreview = document.getElementById('documentPreview');
    const documentName = document.getElementById('documentName');
    const documentDropZone = document.getElementById('documentDropZone');
    const documentInput = document.getElementById('document');

    function showDocumentPreview(files) {
        const file = files[0];
        if (!file) return;
        documentName.textContent = `📄 ${file.name}`;
        documentPreview.style.display = 'block';
        documentDropZone.style.display = 'none';
    }

    function removeDocument() {
        documentInput.value = '';
        documentPreview.style.display = 'none';
        documentDropZone.style.display = 'block';
    }
    
    setupDropZone('documentDropZone', 'document', showDocumentPreview);
    const removeDocBtn = document.querySelector('[data-action="remove-document"]');
    if(removeDocBtn) removeDocBtn.addEventListener('click', removeDocument);


    // --- FORM SUBMISSION ---
    const publicationForm = document.getElementById('publicationForm');
    if (publicationForm) {
        publicationForm.addEventListener('submit', (e) => {
            // On submit, re-populate the 'images' input with the latest file list
            const dataTransfer = new DataTransfer();
            selectedImages.forEach(file => dataTransfer.items.add(file));
            imagesInput.files = dataTransfer.files;
        });
    }
});
