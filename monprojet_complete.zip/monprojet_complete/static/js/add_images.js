document.addEventListener('DOMContentLoaded', function () {
    const dropZone = document.getElementById('dropZone');
    const imageInput = document.getElementById('imageInput');
    const previewArea = document.getElementById('previewArea');
    const submitBtn = document.getElementById('submitBtn');
    const imageForm = document.getElementById('imageForm');
    let selectedFiles = [];

    if(dropZone) {
        // Click to select
        dropZone.addEventListener('click', () => imageInput.click());

        // Drag and drop
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            
            const files = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
            handleFiles(files);
        });
    }

    if(imageInput) {
        // File input change
        imageInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            handleFiles(files);
        });
    }

    function handleFiles(files) {
        selectedFiles = [...selectedFiles, ...files];
        updatePreview();
        updateSubmitButton();
    }

    function updatePreview() {
        previewArea.innerHTML = '';
        selectedFiles.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const preview = document.createElement('div');
                preview.className = 'preview-item';
                preview.innerHTML = `
                    <img src="${e.target.result}" alt="Aperçu de l'image">
                    <button type="button" class="remove-btn" data-index="${index}">✕</button>
                    <input type="text" name="captions" class="caption-input" placeholder="Légende (optionnel)">
                `;
                previewArea.appendChild(preview);
            };
            reader.readAsDataURL(file);
        });
    }

    function removeImage(index) {
        selectedFiles.splice(index, 1);
        updatePreview();
        updateSubmitButton();
    }

    previewArea.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-btn')) {
            const index = parseInt(e.target.dataset.index, 10);
            removeImage(index);
        }
    });

    function updateSubmitButton() {
        if (selectedFiles.length > 0) {
            submitBtn.disabled = false;
        } else {
            submitBtn.disabled = true;
        }
    }

    if (imageForm) {
        // Form submission
        imageForm.addEventListener('submit', (e) => {
            const dataTransfer = new DataTransfer();
            selectedFiles.forEach(file => dataTransfer.items.add(file));
            imageInput.files = dataTransfer.files;
        });
    }
});
