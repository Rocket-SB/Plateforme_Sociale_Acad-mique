
document.addEventListener('DOMContentLoaded', function () {
    const conversationIdElement = document.getElementById('conversation-id');
    if (!conversationIdElement) {
        return;
    }

    const conversationId = JSON.parse(conversationIdElement.textContent);
    const userId = JSON.parse(document.getElementById('user-id').textContent);
    const chatLog = document.querySelector('#chat-log');
    let fileData = null;
    let fileName = null;

    if (chatLog) {
        chatLog.scrollTop = chatLog.scrollHeight;
    }

    const chatSocket = new WebSocket(
        'ws://'
        + window.location.host
        + '/ws/chat/'
        + conversationId
        + '/'
    );

    function createMessageElement(message, file_url, senderId, createdAt) {
        const messageWrapper = document.createElement('div');
        messageWrapper.classList.add('message-bubble-wrapper');
        
        const messageBubble = document.createElement('div');
        messageBubble.classList.add('message-bubble');

        if (file_url) {
            const imgLink = document.createElement('a');
            imgLink.href = file_url;
            imgLink.target = '_blank';
            const img = document.createElement('img');
            img.src = file_url;
            img.classList.add('message-image');
            imgLink.appendChild(img);
            messageBubble.appendChild(imgLink);
        }

        if (message) {
            const messageContent = document.createElement('div');
            messageContent.classList.add('message-content');
            messageContent.textContent = message;
            messageBubble.appendChild(messageContent);
        }

        const messageTimestamp = document.createElement('div');
        messageTimestamp.classList.add('message-timestamp');
        const messageDate = new Date(createdAt);
        messageTimestamp.textContent = `${messageDate.getHours().toString().padStart(2, '0')}:${messageDate.getMinutes().toString().padStart(2, '0')}`;

        if (senderId === userId) {
            messageWrapper.classList.add('sent');
        } else {
            messageWrapper.classList.add('received');
        }

        messageBubble.appendChild(messageTimestamp);
        messageWrapper.appendChild(messageBubble);

        return messageWrapper;
    }

    chatSocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        
        const emptyMessage = chatLog.querySelector('.empty-chat-message');
        if (emptyMessage) {
            emptyMessage.remove();
        }

        const messageElement = createMessageElement(data.message, data.file_url, data.sender_id, data.created_at);
        chatLog.appendChild(messageElement);
        chatLog.scrollTop = chatLog.scrollHeight;
    };

    chatSocket.onclose = function(e) {
        console.error('Chat socket closed unexpectedly');
    };

    document.querySelector('#attach-file-btn').addEventListener('click', function() {
        document.querySelector('#chat-file-input').click();
    });

    document.querySelector('#chat-file-input').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            fileName = file.name;
            const reader = new FileReader();
            reader.onload = function(e) {
                fileData = e.target.result;
                document.querySelector('#file-preview').src = fileData;
                document.querySelector('#file-preview-container').style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });

    document.querySelector('#remove-file-btn').addEventListener('click', function() {
        fileData = null;
        fileName = null;
        document.querySelector('#chat-file-input').value = '';
        document.querySelector('#file-preview-container').style.display = 'none';
    });

    document.querySelector('#chat-form').onsubmit = function(e) {
        e.preventDefault();
        const messageInputDom = document.querySelector('#chat-message-input');
        const message = messageInputDom.value;

        if (message.trim() === '' && !fileData) return;

        chatSocket.send(JSON.stringify({
            'message': message,
            'sender_id': userId,
            'file': fileData,
            'filename': fileName
        }));
        messageInputDom.value = '';
        document.querySelector('#remove-file-btn').click();
        messageInputDom.focus();
    };
});
