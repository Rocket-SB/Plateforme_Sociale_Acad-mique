document.addEventListener('DOMContentLoaded', function() {
    const searchBox = document.getElementById('search-box');
    const pubItems = document.querySelectorAll('.publication-item');

    if (searchBox) {
        searchBox.addEventListener('input', function() {
            const query = this.value.toLowerCase();
            pubItems.forEach(item => {
                const title = item.dataset.title;
                const authors = item.dataset.authors;
                if (title.includes(query) || authors.includes(query)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    pubItems.forEach(item => {
        const radio = item.querySelector('input[type="radio"]');
        if (radio && !radio.disabled) {
            // Handle click on the whole item
            item.addEventListener('click', (e) => {
                if (e.target.tagName !== 'INPUT') {
                    radio.checked = true;
                    // Manually trigger change event
                    const event = new Event('change', { bubbles: true });
                    radio.dispatchEvent(event);
                }
            });

            // Handle radio button change
            radio.addEventListener('change', function() {
                pubItems.forEach(i => i.classList.remove('selected'));
                if (this.checked) {
                    item.classList.add('selected');
                }
            });
        }
    });
});
