-- Script SQL pour créer la base de données MySQL
-- Exécutez ce script dans MySQL avant de lancer les migrations Django

-- Créer la base de données
CREATE DATABASE IF NOT EXISTS research_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Optionnel: Créer un utilisateur dédié pour la base de données
-- CREATE USER 'research_user'@'localhost' IDENTIFIED BY 'your_password_here';
-- GRANT ALL PRIVILEGES ON research_platform.* TO 'research_user'@'localhost';
-- FLUSH PRIVILEGES;

-- Utiliser la base de données
USE research_platform;

-- Note: Les tables seront créées automatiquement par Django lors des migrations
-- Exécutez: python manage.py migrate

